export const imageBaseUrl = "https://api.budbox.fun"
// export const imageBaseUrl = "http://192.168.10.169:8080"