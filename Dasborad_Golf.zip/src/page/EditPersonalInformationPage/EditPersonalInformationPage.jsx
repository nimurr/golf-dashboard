import EditPersonalInfo from "../../component/Main/EditPersonalInfo/EditPersonalInfo"

const EditPersonalInformationPage = () => {
  return <EditPersonalInfo/>
}

export default EditPersonalInformationPage
