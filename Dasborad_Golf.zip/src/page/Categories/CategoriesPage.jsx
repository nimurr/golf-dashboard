import Categories from "../../component/Main/CategoriesBox/Categories"

const CategoriesPage = () => {
  return <Categories />
}

export default CategoriesPage
