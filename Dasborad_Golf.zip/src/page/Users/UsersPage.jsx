import Users from '../../component/Main/Users/Users'

const UsersPage = () => {
  return <Users/>
}

export default UsersPage
