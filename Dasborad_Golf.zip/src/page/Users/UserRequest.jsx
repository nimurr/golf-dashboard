import RecentTransactions from '../../component/Main/Dashboard/RecentTransactions'
 
const UsersRequest = () => {
  return <RecentTransactions/>
}

export default UsersRequest
