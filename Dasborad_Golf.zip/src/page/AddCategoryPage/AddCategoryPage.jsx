import AddCategoryBox from "../../component/Main/AddCategoryBox/AddBox"



const AddCategoryPage = () => {
  return <AddCategoryBox />
}

export default AddCategoryPage
