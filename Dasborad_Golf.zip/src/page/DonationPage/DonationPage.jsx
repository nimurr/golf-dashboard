import Donation from "../../component/Main/Donation/Donation";

const DonationPage = () => {
 return (
 <div>
  <Donation />
 </div>
 );
};

export default DonationPage;