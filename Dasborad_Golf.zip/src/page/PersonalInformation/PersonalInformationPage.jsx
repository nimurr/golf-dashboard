import PersonalInformation from "../../component/Main/PersonalInformation/PersonalInformation"

const PersonalInformationPage = () => {
  return <PersonalInformation />
}

export default PersonalInformationPage
