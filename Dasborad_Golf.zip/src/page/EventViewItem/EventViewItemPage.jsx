import EventViewItem from "../../component/Main/EventViewItem/EventViewItem"

const EventViewItemPage = () => {
  return <EventViewItem />
}

export default EventViewItemPage