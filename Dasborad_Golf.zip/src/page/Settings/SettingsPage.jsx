import Settings from "../../component/Main/Settings/Settings"

const SettingsPage = () => {
    return <Settings />
}

export default SettingsPage
