import EditCategoriesBox from "../../component/Main/EditCategoriesBox/EditCategoriesBox"
const EditCategoriesBoxPage = () => {
  return <EditCategoriesBox />
}

export default EditCategoriesBoxPage
