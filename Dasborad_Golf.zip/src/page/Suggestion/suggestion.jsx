import Suggestion from "../../component/Main/Suggestion/suggestion";

const SuggestionPage = () => {
 return (
 <div>
  <Suggestion />
 </div>
 );
};

export default SuggestionPage;