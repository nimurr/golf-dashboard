import Welcome from "../../component/Main/WelcomePage/Welcome";

const WelcomePage = () => {
 return (
 <div>
    <Welcome />
 </div>
 );
};

export default WelcomePage;