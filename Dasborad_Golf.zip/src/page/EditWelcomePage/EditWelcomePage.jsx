import EditWelcome from "../../component/Main/EditWelcome/EditWelcome";

const EditWelcomePage = () => {
 return (
 <div>
    <EditWelcome />
 </div>
 );
};

export default EditWelcomePage;