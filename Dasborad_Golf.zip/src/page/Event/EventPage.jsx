import EventItems from '../../component/Main/Event/EventItems'

const EventItemsPage = () => {
  return <EventItems />
}

export default EventItemsPage
